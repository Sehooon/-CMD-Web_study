const timerStartBtn = document.getElementById("timer_startBtn");
const timerPauseBtn = document.getElementById("timer_pauseBtn");
const timerResetBtn = document.getElementById("timer_resetBtn");
const timerRecordBtn = document.getElementById("timer_recordBtn");
const timerlapboard = document.querySelector(".timer_lap_board");
const addBtn = document.getElementById("timer_addBtn");
const add_1hoursBtn=document.getElementById("add_1hours");
const add_5minBtn=document.getElementById("add_5min");
const add_10secBtn=document.getElementById("add_10sec");
const Moniter = document.getElementById("display_timer");

let timer_sec=0;
let timer_time_stream;

function dis_pos(d_hours, d_min ,d_sec,display) {
    let sec, min, hours;
    if(d_sec<10){ sec="0"+ d_sec.toString();} else{ sec= d_sec.toString();}
    if(d_min<10){ min="0"+ d_min.toString();} else{ min= d_min.toString();}
    if(d_hours<10){ hours="0"+ d_hours.toString();} else{ hours= d_hours.toString();}
    display.innerHTML= hours + " : " + min + " : " + sec;    
}

function print_time(seconds,display) {
    let d_hours=0;
    let d_min=0;
    if(seconds>=3600){ d_hours=Math.floor(seconds/3600); seconds%=3600;}
    if(seconds>=60){  d_min=Math.floor(seconds/60); seconds%=60;}
    dis_pos(d_hours,d_min,seconds,display)
}


timerStartBtn.addEventListener("click",function()  {
    if(timer_sec>0){
        timer_time_stream=setInterval(() => { if(timer_sec>0){timer_sec--; print_time(timer_sec,Moniter);} }, 1000);
        timerStartBtn.hidden=true;
        timerPauseBtn.hidden=false;
        timerRecordBtn.hidden=false;
    }
})


timerResetBtn.addEventListener("click",function() 
{
    timer_sec=0;
    clearInterval(timer_time_stream);
    Moniter.innerHTML="00 : 00 : 00";
    timerStartBtn.hidden=false;
    timerPauseBtn.hidden=true;
    timerRecordBtn.hidden=true;
    timerlapboard.hidden=true;
    while(timerlapboard.hasChildNodes()){
        timerlapboard.removeChild(timerlapboard.firstChild);
    }
})

timerPauseBtn.addEventListener("click",function () 
{ clearInterval(timer_time_stream); 
    timerPauseBtn.hidden=true; 
    timerStartBtn.hidden=false;
    timerRecordBtn.hidden=true;
});


addBtn.addEventListener("click",function() {
    if(addBtn.innerText==="시간 추가")
    {
        add_1hoursBtn.hidden=false;
        add_5minBtn.hidden=false;
        add_10secBtn.hidden=false;
        addBtn.innerText="닫기";
    }
    else{
        add_1hoursBtn.hidden=true;
        add_5minBtn.hidden=true;
        add_10secBtn.hidden=true;
        addBtn.innerText="시간 추가";
    }
    
});

timerRecordBtn.addEventListener("click",function() {
    var timer_li=document.createElement("li");
    timerlapboard.hidden=false;
    timer_li.innerHTML=Moniter.innerHTML;
    timerlapboard.appendChild(timer_li);
});

add_1hoursBtn.addEventListener("click",function() { timer_sec+=3600; print_time(timer_sec,Moniter);});
add_5minBtn.addEventListener("click",function() { timer_sec+=300; print_time(timer_sec,Moniter);});
add_10secBtn.addEventListener("click",function () { timer_sec+=10; print_time(timer_sec,Moniter);});