const startBtn=document.getElementById("stopWatch_startBtn");
const stopBtn=document.querySelector("#stopWatch_stopBtn");
const pauseBtn=document.querySelector("#stopWatch_pauseBtn");
const continueBtn=document.querySelector("#stopWatch_continueBtn");
const recordBtn=document.querySelector("#stopWatch_recordBtn");
const DISPLAY=document.getElementById("display_stopwatch");
const record=document.querySelector(".stopwatch_lap_board");

let seconds = 0;
let time_stream;

function resetClock() { seconds=0; DISPLAY.innerHTML="00 : 00 : 00";}


function dis_pos(d_hours, d_min ,d_sec,display) {
    let sec, min, hours;
    if(d_sec<10){ sec="0"+ d_sec.toString();} else{ sec= d_sec.toString();}
    if(d_min<10){ min="0"+ d_min.toString();} else{ min= d_min.toString();}
    if(d_hours<10){ hours="0"+ d_hours.toString();} else{ hours= d_hours.toString();}
    display.innerHTML= hours + " : " + min + " : " + sec;    
}

function print_time(seconds,display) {
    let d_hours=0;
    let d_min=0;
    if(seconds>=3600){ d_hours=Math.floor(seconds/3600); seconds%=3600;}
    if(seconds>=60){  d_min=Math.floor(seconds/60); seconds%=60;}
    dis_pos(d_hours,d_min,seconds,display)
}


startBtn.addEventListener("click",function(){ 
    time_stream=setInterval(() => {seconds++; print_time(seconds,DISPLAY);},1000);
    startBtn.hidden=true;
    recordBtn.hidden=false;
    pauseBtn.hidden=false;
});


recordBtn.addEventListener("click",function() {
    var li=document.createElement('li');
    li.innerHTML=DISPLAY.innerHTML;
    record.appendChild(li);
    record.hidden=false;
})

pauseBtn.addEventListener("click",function() 
{
    clearInterval(time_stream);
    startBtn.hidden=false;
    pauseBtn.hidden=true;
});

stopBtn.addEventListener("click",function() {
    clearInterval(time_stream);
    resetClock(seconds,DISPLAY); 
    record.hidden=true;
    pauseBtn.hidden=true;
    startBtn.hidden=false;
    while ( record.hasChildNodes() ) { record.removeChild( record.firstChild ); }
});
