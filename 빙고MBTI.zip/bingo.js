const BingoFram = document.querySelector(".bingoFrame");
const bingo=BingoFram.querySelectorAll("td");
const bingonum=document.getElementById("bingonum");

const BASE_COLOR= "darkseagreen";   
const OTHER_COLOR="white";

function cliked_bingo(){
    for(let bingoBtn of bingo){
        bingoBtn.addEventListener("click",function() {
            if(bingoBtn.style.backgroundColor === BASE_COLOR) {bingoBtn.style.backgroundColor=OTHER_COLOR;}
            else { bingoBtn.style.backgroundColor=BASE_COLOR; }
        });
    }
}

function check_row(num){
    if(bingo[num].style.backgroundColor === BASE_COLOR && bingo[num+5].style.backgroundColor === BASE_COLOR && bingo[num+10].style.backgroundColor===BASE_COLOR
         && bingo[num+15].style.backgroundColor === BASE_COLOR && bingo[num+20].style.backgroundColor === BASE_COLOR){return true;}
    else{false;}
}
function r_diagnol(num) {
    if(bingo[num].style.backgroundColor === BASE_COLOR && bingo[num+6].style.backgroundColor === BASE_COLOR && bingo[num+12].style.backgroundColor === BASE_COLOR
        && bingo[num+18].style.backgroundColor === BASE_COLOR && bingo[num+24].style.backgroundColor === BASE_COLOR ) {return true;}
        else{false;}
}
function l_diagnol(num) {
    if(bingo[num+4].style.backgroundColor === BASE_COLOR && bingo[num+8].style.backgroundColor === BASE_COLOR && bingo[num+12].style.backgroundColor === BASE_COLOR
        && bingo[num+16].style.backgroundColor === BASE_COLOR && bingo[num+20].style.backgroundColor === BASE_COLOR ) {return true;}
        else{false;}
}

function check_col(num){
    if(bingo[num].style.backgroundColor === BASE_COLOR && bingo[num+1].style.backgroundColor === BASE_COLOR && bingo[num+2].style.backgroundColor===BASE_COLOR
    && bingo[num+3].style.backgroundColor === BASE_COLOR && bingo[num+4].style.backgroundColor === BASE_COLOR ){return true;}
    else{false;}
}

function count_bingo(){
    let bingo_count=0;
    for(let i=0;i<5;i++){ if(check_row(i)){bingo_count+=1;} if(check_col(5*i)){bingo_count+=1;}}
    if(r_diagnol(0)){bingo_count+=1;} 
    if(l_diagnol(0)){bingo_count+=1;}
    bingonum.innerText=`bingo : ${bingo_count}`;
}

function init() { cliked_bingo(); setInterval(count_bingo, 30); }
init();